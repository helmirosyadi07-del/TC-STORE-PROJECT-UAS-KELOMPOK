<?= view('layout/header_admin'); ?>

    <div class="d-flex justify-content-between align-items-center mb-5">
        <div>
            <h1 class="fw-800 m-0 text-white">PESANAN <span class="text-primary">MASUK</span></h1>
            <p class="text-secondary small mt-1">Pantau orderan masuk secara realtime disini.</p>
        </div>
    </div>

    <div class="row mb-5">
        <div class="col-lg-4 mb-3">
            <div class="glass-card h-100 d-flex flex-column justify-content-center">
                <p class="text-secondary small fw-bold mb-1">TOTAL PENDAPATAN</p>
                <h2 class="fw-800 m-0 text-success">Rp <?= number_format($total_pendapatan, 0, ',', '.'); ?></h2>
            </div>
        </div>
        <div class="col-lg-4 mb-3">
            <div class="glass-card h-100 d-flex flex-column justify-content-center">
                <p class="text-secondary small fw-bold mb-1">TOTAL TRANSAKSI</p>
                <h2 class="fw-800 m-0 text-white"><?= $total_transaksi ?> <span class="fs-6 text-secondary fw-normal">Pesanan</span></h2>
            </div>
        </div>
        <div class="col-lg-4 mb-3">
            <div class="glass-card h-100 d-flex flex-column justify-content-center" style="border: 1px solid <?= ($pending_orders > 0) ? '#ffc107' : 'rgba(255,255,255,0.1)' ?>;">
                <p class="text-secondary small fw-bold mb-1">MENUNGGU KONFIRMASI</p>
                <h2 class="fw-800 m-0 <?= ($pending_orders > 0) ? 'text-warning' : 'text-white' ?>"><?= $pending_orders ?> <span class="fs-6 text-secondary fw-normal">Pending</span></h2>
            </div>
        </div>
    </div>

    <div class="glass-card">
        <h5 class="fw-bold mb-4 text-white">DAFTAR ANTRIAN PESANAN</h5>
        <div class="table-responsive">
            <table class="table table-borderless align-middle m-0 text-white">
                <thead class="text-secondary small text-uppercase">
                    <tr style="border-bottom: 1px solid var(--border);">
                        <th class="pb-3">TANGGAL</th>
                        <th class="pb-3">PEMESAN</th>
                        <th class="pb-3">TOTAL</th>
                        <th class="pb-3">STATUS</th>
                        <th class="pb-3 text-end">AKSI</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(!empty($orders)): ?>
                        <?php foreach($orders as $o): ?>
                        <tr style="border-bottom: 1px solid rgba(255,255,255,0.02);">
                            <td class="py-4 small"><?= date('d/m/Y H:i', strtotime($o['created_at'] ?? 'now')) ?></td>
                            <td>
                                <span class="fw-bold d-block"><?= $o['user_id'] ?? 'User' ?></span>
                                <small class="text-secondary">Order ID: #<?= $o['id'] ?></small>
                            </td>
                            <td class="fw-bold">Rp <?= number_format($o['total_harga'], 0, ',', '.') ?></td>
                            <td>
                                <?php if($o['status'] == 'Pending'): ?>
                                    <span class="badge bg-warning text-dark rounded-pill px-3">Pending</span>
                                <?php else: ?>
                                    <span class="badge bg-success bg-opacity-10 text-success rounded-pill px-3">Berhasil</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end">
                                <?php if($o['status'] == 'Pending'): ?>
                                    <form action="<?= base_url('admin/update_status/'.$o['id']) ?>" method="post" class="d-inline">
                                        <button type="submit" class="btn btn-success btn-sm rounded-circle" title="Terima Pesanan" onclick="return confirm('Konfirmasi pesanan ini sudah dibayar?');">
                                            ✔
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <span class="text-secondary small fst-italic">Selesai</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center py-5 text-secondary">
                                Belum ada pesanan masuk, santai dulu bos. ☕
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div> <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>